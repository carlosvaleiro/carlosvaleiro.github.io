/* My CODE */

function getData() {
	$.ajax({
		url: "/acme/js/acme.json",
		dataType: "json",
		success: function (data) {


    var name = jsonData[pageName].name;
    console.log(name);

    var path = jsonData[pageName].path;
    console.log(path);

    var description = jsonData[pageName].description;
    console.log(description);

    var manufacturer = jsonData[pageName].manufacturer;
    console.log(manufacturer);

    var price = jsonData[pageName].price;
    console.log(price);

    var reviews = jsonData[pageName].reviews;
    console.log(reviews);

/* MY FRIEND'S CODE ************************************************************************* */
            

//when the document is ready and done loading, call the getData function
$(document).ready(function () {
	getData();
	$('#productWrapper').hide();
});

function getData() {
	$.ajax({
		url: "js/acme.json",
		dataType: "json",
		success: function (data) {
			console.log(data);
			//fill the empty list items in the html with the navigation link names in the JSON Navigation object
			$("#li1").html(data.Navigation.link1);
			$("#li2").html(data.Navigation.link2);
			$("#li3").html(data.Navigation.link3);
			$("#li4").html(data.Navigation.link4);
			$("#li5").html(data.Navigation.link5);
		}
	});
}

// Intercept the menu link clicks
$("#pageNav").on("click", "a", function (evt) {
	// Intercept the menu link clicks
	evt.preventDefault();
	//get the link that was clicked on
	var link = $(this).text();
	console.log(link);

	//hide home page and show the product page
	if (link != 'Home') {
		$('#homepageWrapper').hide();
		$('#productWrapper').show();

	$.ajax({
		url: "js/acme.json",
		dataType: "json",
		success: function (data) {
			console.log(data);
			//find the path to the +product .png
			var picPath=(data[link].path);
			console.log(picPath);
			//insert the product content
			$('#contentTitle').text(data[link].name);
			$("#productImg").html("<img src='" + picPath + "'>");
			$('#description').text(data[link].description);
			$('#madeBy').text(' ' + data[link].manufacturer);
			$('#reviewScores').text(data[link].reviews + '/5 stars');
			$('#price').text('Price: $' + data[link].price);
		}
	});
	}
	else{
		$('#homepageWrapper').show();
		$('#productWrapper').hide();
		$('#contentTitle').text("Welcome to Acme!");

	}
});

            
/*  MY OTHER FRIEND'S CODE ********************************************************************************* */
            
var selectLink = "";
var jsonData = null;
//Gets the links ready
$(".link").ready(function () {
	$.ajax({
		url: "/acme/js/acme.json",
		dataType: "json",
		success: function (data) {
			console.log(data);
			$("#links1").html("<a href='#'>" + data.nav.link0 + "</a>");
			$("#links2").html("<a href='#'>" + data.nav.link1 + "</a>");
			$("#links3").html("<a href='#'>" + data.nav.link2 + "</a>");
			$("#links4").html("<a href='#'>" + data.nav.link3 + "</a>");
			$("#links5").html("<a href='#'>" + data.nav.link4 + "</a>");
			$("#prod").hide();
		}
		//want to use onclick events when you select the links
	});

})
$("#links1").on("click", function () {
	var link = $(this).find("a").html();
	console.log("the link is:" + link);
	replacePro(link);
});
$("#links2").on("click", function () {
	var link = $(this).find("a").html();
	console.log("the link is:" + link);
	$.ajax({
		url: "/acme/js/acme.json",
		dataType: "json",
		success: function (data) {
			var picPath= data.Anvils.path;
			var made = data.Anvils.manufacturer;
			var summary = data.Anvils.description;
			var review= data.Anvils.reviews;
			var price= data.Anvils.price;
			$("#productImage").html("<img src='"+picPath+"'>");
			$("#made").html("<strong>Made By:</strong> "+made);
			$("#summary").html(summary);
			$("#review").html("<strong>Reviews:</strong> "+review);
			$("#price").html("Price: "+ price);
		}
	});
	replacePro(link);
});
$("#links3").on("click", function () {
	var link = $(this).find("a").html();
	console.log("the link is:" + link);
	$.ajax({
		url: "/acme/js/acme.json",
		dataType: "json",
		success: function (data) {
			var picPath= data.Explosives.path;
			var made = data.Explosives.manufacturer;
			var summary = data.Explosives.description;
			var review= data.Explosives.reviews;
			var price= data.Explosives.price;
			$("#productImage").html("<img src='"+picPath+"'>");
			$("#made").html("<strong>Made By:</strong> "+made);
			$("#summary").html(summary);
			$("#review").html("<strong>Reviews:</strong> "+review);
			$("#price").html("Price: "+ price);
		}
	});
	replacePro(link);
});
$("#links4").on("click", function () {
	var link = $(this).find("a").html();
	console.log("the link is:" + link);
	replacePro(link);
});
$("#links5").on("click", function () {
	var link = $(this).find("a").html();
	console.log("the link is:" + link);
	replacePro(link);
});

function replacePro(link) {
	if (link !== "Home") {
		$("#rocket").hide();
		$("#lower-half").hide();
		$("#prod").show();
	} else {
		$("#rocket").show();
		$("#lower-half").show();
		$("#prod").hide();
	}
}
